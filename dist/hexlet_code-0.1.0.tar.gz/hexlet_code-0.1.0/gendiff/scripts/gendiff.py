#!/usr/bin/env python3

import argparse

def main():
    """Parsing arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--format', default='stylish',
                        help='output format (default: "stylish")')
    args = parser.parse_args()


if __name__ == '__main__':
    main()
